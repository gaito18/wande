<?php

class  DataHelper
{
    /** @var string */
    protected $filePath;

    /**
     * @param $name
     * @param $arguments
     * @return $this|DataHelper|null
     */
    public function __call($name, $arguments)
    {
        switch ($name) {
            case 'get':
                return $this->getContent() ? $this->getContent()[$arguments[0]] : null;
                break;
            case 'set':
                return $this->setValue($arguments[0], $arguments[1]);
                break;
        }
        return $this;
    }

    /**
     * @return mixed|null
     */
    public function getContent()
    {
        if ($this->fileExist()) {
            return json_decode(file_get_contents($this->filePath), true);
        }
        return null;
    }

    /**
     * @return bool
     */
    public function fileExist()
    {
        return file_exists($this->filePath);
    }

    /**
     * @param $content
     * @return $this
     */
    public function setContent($content)
    {
        if (is_string($content)) {
            file_put_contents($this->filePath, $content);
        } else if (is_array($content)) {
            file_put_contents($this->filePath, json_encode($content, JSON_PRETTY_PRINT));
        }
        return $this;
    }

    public function setValue($key, $value)
    {
        $content = $this->getContent();
        if ($content) {
            $content[$key] = $value;
            $this->setContent($content);
        } else {
            $this->setContent([
                $key => $value
            ]);
        }
        return $this;
    }

    /**
     * @param $path
     * @return $this
     */
    public function setPath($path)
    {
        $this->filePath = $path;
        return $this;
    }
}